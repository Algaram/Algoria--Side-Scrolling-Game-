import java.awt.*;
import java.awt.event.*;
import java.util.*;

//A Simple version of the scrolling game, featuring Avoids, Collects, SpecialAvoids, and SpecialCollects
//Players must reach a score threshold to win.
//If player runs out of HP (via too many Avoid/SpecialAvoid collisions) they lose.
public class SimpleGame extends SSGEngine {
    
    
    //Starting Player coordinates
    protected static final int STARTING_PLAYER_X = 0;
    protected static final int STARTING_PLAYER_Y = 100;
    
    //Score needed to win the game
    protected static final int SCORE_TO_WIN = 300;
    
    //Maximum that the game speed can be increased to
    //(a percentage, ex: a value of 300 = 300% speed, or 3x regular speed)
    protected static final int MAX_GAME_SPEED = 300;
    //Interval that the speed changes when pressing speed up/down keys
    protected static final int SPEED_CHANGE_INTERVAL = 20;    
    
    public static final String INTRO_SPLASH_FILE = "media_files/splash.gif";        
    //Key pressed to advance past the splash screen
    public static final int ADVANCE_SPLASH_KEY = KeyEvent.VK_ENTER;
    
    //Interval that Entities get spawned in the game window
    //ie: once every how many ticks does the game attempt to spawn new Entities
    protected static final int SPAWN_INTERVAL = 45;

    
    //A Random object for all your random number generation needs!
    public static final Random rand = new Random();
    
    //player's current score
    protected int score;
    
    
    //Stores a reference to game's Player object for quick reference (Though this Player presumably
    //is also in the DisplayList, but it will need to be referenced often)
    protected Player player;
    
    
    public SimpleGame(){
        super();
    }
    
    public SimpleGame(int gameWidth, int gameHeight){
        super(gameWidth, gameHeight);
    }
    
    
    //Performs all of the initialization operations that need to be done before the game starts
    protected void pregame(){
        this.setBackgroundColor(Color.BLACK);
        this.player = new Player(STARTING_PLAYER_X, STARTING_PLAYER_Y);
        this.toDraw.add(player); 
        this.score = 0;
        super.setSplashImg(INTRO_SPLASH_FILE);
    }
    
    //Called on each game tick
    protected void gameUpdate(){
        //scroll all AutoScroller Entities on the game board
        performScrolling();   
        //spawn new per interval
        if (super.getTicksElapsed() % SPAWN_INTERVAL == 0){
            performSpawning();
            gcOffscreenEntities();
        }
        updateTitleText();
        checkAndHandleCollisions();
        
    }
    

    //Update the text at the top of the game window
    protected void updateTitleText(){
        setTitle("Score: " + score + " // HP: " + player.getHP() + " // Speed: " + getUniversalSpeed());
    }
    

    //Scroll all AutoScroller entities per their respective scroll speeds
    protected void performScrolling(){

        //****   Implement me!   ****
        for(int i = 0; i < toDraw.size(); i++){ // lopps through entities
            Entity e = toDraw.get(i);
            //check for scroll
            if(e instanceof AutoScroller){
                ((AutoScroller)e).scroll();
            }
        }
    }

    
    //Handles "garbage collection" of the entities
    //Flags entities in the displaylist that are no longer relevant
    //(i.e. will no longer need to be drawn in the game window).
    protected void gcOffscreenEntities(){

        //****   Implement me!   ****
        for(int i = 0; i < toDraw.size(); i++){ // once entities leave remove
            Entity e = toDraw.get(i);
            if(e != player && e.getX() + e.getWidth() < 0){ // checks if enttiy is player
                e.flagForGC(true); // Flag for garbage collection
            }
        }
    }
    
    
    
    //Spawn new Entities on the right edge of the game board
    protected void performSpawning(){

        //****   Implement me!   ****
        int y = rand.nextInt(getWindowHeight() - 100); //random set y
        int entityType = rand.nextInt(100); // determines what to spawn
        
        if(entityType < 50){ // 50% chance for avoid
            Avoid avoid = new Avoid(getWindowWidth(), y);
            toDraw.add(avoid);
        }
        else if(entityType < 60){ // 10% chance for specialavoid
            SpecialAvoid sAvoid = new SpecialAvoid(getWindowWidth(), y);
            toDraw.add(sAvoid);
        }
        else if(entityType < 90){ // 30% chance for collect
            Collect collect = new Collect(getWindowWidth(), y);
            toDraw.add(collect);
        }
        else{ // 10% chance for specialcollect
            SpecialCollect sCollect = new SpecialCollect(getWindowWidth(), y);
            toDraw.add(sCollect);
        }

    }
    
    //Called once the game is over, performs any end-of-game operations
    protected void postgame(){
        
        if(score >= SCORE_TO_WIN){
            super.setTitle("Game Over You Win!");
        }
        else{
            super.setTitle("Game Over You Lose!");
        }
    }
    
    //Returns a boolean indicating if the game is over (true) or not (false)
    //Game can be over due to either a win or lose state
    protected boolean checkForGameOver(){

        //****   placeholder... Implement me!   ****

        // win game
        if(score >= SCORE_TO_WIN){
            return true;
        }
        
        // lost game
        if(player.getHP() <= 0){
            return true;
        }
        
        return false;

    }
    
    //Reacts to a single key press on the keyboard
    protected void reactToKeyPress(int key){
        
        //if a splash screen is up, only react to the advance splash key
        if (getSplashImg() != null){
            if (key == ADVANCE_SPLASH_KEY)
                super.setSplashImg(null);
            return;
        }

        // paiuse game
        if(key == KEY_PAUSE_GAME){
            isPaused = !isPaused;
            return;
        }
        
        // speed change
        if(key == SPEED_UP_KEY){
            int currentSpeed = getUniversalSpeed();
            if(currentSpeed < MAX_GAME_SPEED){
                setUniversalSpeed(currentSpeed + SPEED_CHANGE_INTERVAL);
            }
        }
        else if(key == SPEED_DOWN_KEY){
            int currentSpeed = getUniversalSpeed();
            if(currentSpeed > SPEED_CHANGE_INTERVAL){
                setUniversalSpeed(currentSpeed - SPEED_CHANGE_INTERVAL);
            }
        }
        
        // movements (checks for borders too)
        if(!isPaused){
            if(key == UP_KEY){
                // up
                int newY = Math.max(0, player.getY() - player.getMoveSpeed());
                player.setY(newY);
            }
            else if(key == DOWN_KEY){
                // down
                int newY = Math.min(getWindowHeight() - player.getHeight(), 
                                player.getY() + player.getMoveSpeed());
                player.setY(newY);
            }
            else if(key == LEFT_KEY){
                // left
                int newX = Math.max(0, player.getX() - player.getMoveSpeed());
                player.setX(newX);
            }
            else if(key == RIGHT_KEY){
                // right
                int newX = Math.min(getWindowWidth() - player.getWidth(), 
                                player.getX() + player.getMoveSpeed());
                player.setX(newX);
            }
        }
    }

    private void checkAndHandleCollisions(){
        Collection<Entity> collisions = findAllCollisions(player);
        
        for(Entity e : collisions){
            if(e instanceof CollisionReactive){
                CollisionReactive cr = (CollisionReactive)e;
                
                //change score but not allowing negatives
                score += cr.getScoreChange();
                if(score < 0) score = 0; 
                
                //changes hp
                player.modifyHP(cr.getHPChange());
                
                //removes entity if collided
                e.flagForGC(true);
            }
        }
    }
    
    
    
    //Handles reacting to a single mouse click in the game window
    protected MouseEvent reactToMouseClick(MouseEvent click){
       
        //Mouse functionality is not used at all in the Starter game...
        //you may want to override this function for a CreativeGame feature though!

        return click;//returns the mouse event for any child classes overriding this method
    }

    
    
    
    
}
