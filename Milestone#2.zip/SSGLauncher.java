//Contains main... run me to launch the game!
public class SSGLauncher{
    
    //Initializes and launches the game
    public static void main(String[] args){              
        SSGEngine game = new RamirezGame();
        game.launchGame();    
    }        
    
}
